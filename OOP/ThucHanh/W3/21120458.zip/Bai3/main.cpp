#include"DonThuc.h"
#include"DaThuc.h"
int main() {
	menu();
	return 0;
}