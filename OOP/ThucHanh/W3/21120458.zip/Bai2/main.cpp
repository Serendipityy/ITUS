#include "PhanSo.h"
#include "MangPS.h"
int main() {
	menu();
	return 0;
}