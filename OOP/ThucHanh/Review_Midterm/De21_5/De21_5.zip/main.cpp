#include "QLGiaoDich.h"
int main() {
	QLGiaoDich ql;
	ql.nhapDS();
	ql.xuatDS();
	ql.TongSoLuongTungLoaiGD();
	ql.timGiaoDichTienTeMax();
	ql.xuatGiaoDichThang01();
	return 0;
}