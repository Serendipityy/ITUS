﻿#include "bookManagement.h"

int main() {
    menu();
    return 0;
}